package com.assignment.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.assignment.demo.model.Book;
import com.assignment.demo.repository.BookRepository;

@RestController
@RequestMapping("books")
public class BookController {

	@Autowired
	BookRepository bookrepository;
	
	// retrieve all books from database
	@GetMapping("all")
	public List<Book> getAllBook()
	{
		List<Book> book=(List<Book>) bookrepository.findAll();
		return book;
	}
	
	
	// insert new student into database
	@PostMapping("create")
	public Book addBook(@RequestBody Book book)
	{
		return bookrepository.save(book);
	}
	
	// get particular student by their ID
	@GetMapping("book/{id}")
	public Optional<Book> getBookId(@PathVariable int id)
	{
		return bookrepository.findById(id);
	}
//	@GetMapping("book/{pub}")
//	public Optional<Book> getBookPub(@PathVariable int pub)
//	{
//		return bookrepository.findById(pub);
//	}
	
	// update existing student 
	@PutMapping("update/{id}")
	public Book updatebook(@RequestBody Book book)
	{
		return bookrepository.save(book);
	}
	
	// delete particular student from database
	@DeleteMapping("delete/{id}")
	public void deleteBook(@PathVariable int id)
	{
		bookrepository.deleteById(id);
	}
	@DeleteMapping("deleteAll")
	public void delete()
	{
		bookrepository.deleteAll();
		
	}
	
}
