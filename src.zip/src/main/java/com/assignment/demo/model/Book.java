package com.assignment.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.transaction.annotation.EnableTransactionManagement;

@Entity
@Table(name = "Books")
	@EnableTransactionManagement
	public class Book {
		
		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		@Column(name = "book_id")
		private int id;
		
		@Column(name = "description")
		private String desc;
		
		@Column(name = "published")
		private int pub;
		
		@Column(name="title")
		private String tt;

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getDesc() {
			return desc;
		}

		public void setDesc(String desc) {
			this.desc = desc;
		}

		public int getPub() {
			return pub;
		}

		public void setPub(int pub) {
			this.pub = pub;
		}

		public String getTt() {
			return tt;
		}

		public void setTt(String tt) {
			this.tt = tt;
		}
		

}
