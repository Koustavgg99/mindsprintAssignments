package com.assignment.demo;

//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
class SpringAssignmentApplicationTests {

/*	@Test
	void contextLoads() {
	}
*/
}
