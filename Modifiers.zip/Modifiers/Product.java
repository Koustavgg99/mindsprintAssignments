package Modifiers;

class Inheritance {
	int id=78;
	String name="Amul";
	public void display()
	{
		System.out.println("id:	"+id+"name"+name);
	}
	
}
class A extends Inheritance
{
	int count=50;
	String category="butter";
	public void display()
	{
		System.out.println("count:"+count+"category:"+category);
	}
	
	
}
class B extends Inheritance
{
	int count=90;
	String category="milk";
	public void display()
	{
		System.out.println("count:"+count+"category:"+category);
	}
	
	
}
class C extends Product
{
	int count=56;
	String category="choco";
	public void display()
	{
		System.out.println("count:"+count+"category:"+category);
	}
	
	
}
class subA extends A
{
	int price=30;
	int total_price=price*count;
	public void display()
	{
	System.out.println("Total Price: "+total_price+" id:"+id+" name:"+name+" category: "+category);
	}
}
class subB extends B
{
	int price=10;
	int total_price=price*count;
	public void display()
	{
	System.out.println("Total Price: "+total_price+" id:"+id+" name:"+name+" category: "+category);
	}
}
public class Product
{
	public static void main(String[] args)
	{
		subB b1= new subB();
		subA a1= new subA();
		a1.display();
		b1.display();
	}

}
