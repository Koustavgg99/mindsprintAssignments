package Modifiers;

public class functionOverloading {
	public int area(int diag1,int diag2)
	{
		int res=(diag1*diag2)/2;
		return res;
	}
	public int area(int radius)
	{
		int res=(int)3.14*radius*radius;
		return res;
	}
	public float area(float l,float b)
	{
		return l*b;
	}
	public long area(long s)
	{
		return s*s;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		functionOverloading func=new functionOverloading();
		int r=func.area(6,8);
		System.out.println("The area of rhombus is:"+r);
		int r1=func.area(5);
		System.out.println("The area of circle is:"+r1);
		float r2=func.area(6.5f,8f);
		System.out.println("The area of rectangle is:"+r2);
		long r3=func.area(473839l);
		System.out.println("The area of square is:"+r3);

	}

}
