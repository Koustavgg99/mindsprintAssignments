package Modifiers;
import java.util.*;
public class CollectionPrac {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedHashSet L1= new LinkedHashSet();
		L1.add(5);
		L1.add(7);
		L1.add(5.4f);
		L1.add(7.56f);
		L1.add('c');
		L1.add('d');
		L1.add(true);
		System.out.println("HashSet 1 is :"+L1);
		L1.add(76);
		L1.add(69f);
		System.out.println("HashSet 1 is :"+L1);
		L1.remove('d');
		System.out.println("HashSet 1 is :"+L1);
		System.out.println(L1.contains(5));
		System.out.println(L1.contains("c"));
		L1.clear();
		System.out.println("HashSet 1 is :"+L1);
		LinkedHashSet<Integer> L2= new LinkedHashSet<>();
		Scanner sc= new Scanner(System.in);
		while(L2.size()<10)
		{
			System.out.println("Enter Number:");
			int num=sc.nextInt();
			L2.add(num);
		}
		System.out.println("HashSet 2 is :"+L2);
		L2.add(76);
		L2.add(69);
		System.out.println("HashSet 2 is :"+L2);
		L2.remove(69);
		System.out.println("HashSet 1 is :"+L2);
		System.out.println(L2.contains(5));
		System.out.println(L2.contains("c"));
		L2.clear();
		System.out.println("HashSet 2 is :"+L2);
		TreeSet<String>prog=new TreeSet<>();
		prog.add("C");
		prog.add("C++");
		prog.add("Java");
		prog.add("C#");
		prog.add("Python");
		prog.add("Go");
		System.out.println("TreeSet  is :"+prog);
		prog.remove("C");
		prog.remove("Python");
		System.out.println("TreeSet  is :"+prog);
		prog.add("Ruby");
		prog.add("JS");
		prog.add("HTML");
		System.out.println("TreeSet  is :"+prog);
		System.out.println(prog.contains("Java"));
		prog.clear();
		System.out.println("TreeSet  is :"+prog);
		
		
		
		
		

	}

}
