package Modifiers;
import java.util.*;
public class LinkedListprac {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a1=12;

        LinkedList<String> ll = new LinkedList<String>();

        ll.add("May");
        ll.add("June");
        ll.add("July");
        ll.add("August");
        ll.add("April");
        ll.add("November");
        System.out.println(ll);      


        ll.addLast("December");
        System.out.println(ll);  

        ll.addFirst("January");
        System.out.println(ll);

        
        ll.add(1,"February");
        ll.add(2, "March");
        System.out.println(ll);  
        
        ll.add(8, "September");
        ll.add(9,"October");
        System.out.println(ll); 
        ll.remove("April");
        System.out.println(ll); 
        ll.add(3,"April");
        System.out.println(ll); 
        for(int i=0;i<12;i++)
        {
        	if(i%2==0)
        	{
        		System.out.println("Odd is :"+ll.get(i));
        	}
        	else {
        	System.out.println("Even is:"+ll.get(i));
        	}
       
        	
        }
        System.out.println("First is: "+ll.get(0)+" Last is:"+ll.get(11));
        ll.remove("October");
        System.out.println(ll); 
       for(int i=0;i<ll.size();i++) {
			if(ll.get(i)=="January" || ll.get(i)=="February" || ll.get(i)=="December" )  {
				System.out.println("Yes it is Present");
			}
		}
		System.out.println();
		
		
		System.out.println(ll.peekFirst());
		System.out.println(ll.peekLast());
		System.out.println(ll.pollFirst());
		System.out.println(ll.pollLast());
		
		System.out.println(ll);
        
        	
       
        
        
        
        }


       

       
	}





