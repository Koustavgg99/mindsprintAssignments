package Modifiers;
import java.util.*;
public class hashMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<Integer,String>lhm=new LinkedHashMap<Integer,String>();
		lhm.put(91, "India");
		lhm.put(9, "Pakistan");
		lhm.put(1, "Indonesia");
		lhm.put(911, "Iran");
		lhm.put(391, "canada");
		System.out.println("Linked hash map is : "+lhm);
        for (Integer key : lhm.keySet()) {
            System.out.println(key + ":\t" + lhm.get(key));
        }
        System.out.println("LinkedHashMap contains India as value? : " + lhm.containsValue("India"));
        System.out.println("LinkedHashMap contains 45 as key? : " + lhm.containsKey(45));
        
        System.out.println("Linked has deleted  : "+lhm.remove(9));
        Map<Integer,String>lhm1=new LinkedHashMap<Integer,String>();
		lhm1.put(600, "Bihar");
		lhm1.put(99383, "WB");
		lhm1.put(5, "Delhi");
		System.out.println("Linked hash map is : "+lhm1);
		lhm.putAll(lhm1);
		System.out.println("merged Linked hash map is : "+lhm);
		lhm.remove(5);
		System.out.println("merged Linked hash map is : "+lhm);
		System.out.println("merged Linked hash map is empty? : "+lhm.isEmpty());
		lhm.clear();
		System.out.println("merged Linked hash map is : "+lhm);
		
		
		
        
        
		

	}

}
