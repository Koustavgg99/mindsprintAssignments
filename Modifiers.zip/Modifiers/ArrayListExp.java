package Modifiers;
import java.util.*;
public class ArrayListExp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	ArrayList<String> al=new ArrayList<String>();  

	System.out.println("Initial size of Arraylist is "+ al.size());  // SIZE OF ARRAYLIST

	al.add("Mango");
	al.add("Apple");
	al.add("Grape");
	al.add("Pineapple");
	al.add("Orange");
	al.add("Melon");
	al.add("Kolkata");
	al.add("Chennai");
	al.add("Football");
	al.add("Books");
	System.out.println("New Arraylist is "+al);
	System.out.println("New size of Arraylist is "+al.size()); 
	al.remove(9);
	System.out.println("New Arraylist is "+al);
	System.out.println("New size of Arraylist is "+al.size()); 
	al.remove(2);
	al.remove(5);
	System.out.println("New Arraylist is "+al);
	System.out.println("New size of Arraylist is "+al.size());
	System.out.println("element at postion 4 and 6 are:"+al.get(3)+" and "+al.get(5));
	al.set(6, "Singing");
	System.out.println("New Arraylist is "+al);
	System.out.println("New size of Arraylist is "+al.size());
	Collections.reverse(al);
	System.out.println("New Arraylist is "+al);
	al.add(3, "Kerala");
	al.add(1,"mango");
	System.out.println("New Arraylist is "+al);
	System.out.println("New size of Arraylist is "+al.size());
	System.out.println("New sub Arraylist is "+al.subList(2, 5));
	

	}

}
