package Modifiers;

abstract class MNC{
	abstract void leave();
	abstract void holidays();
	MNC()
	{
		System.out.println("This is MNC class");
		
		
	}
	void comp1()
	{
		System.out.println("this is comp1");
	}
	
}
abstract class Mindsprint extends MNC
{
	abstract void leave();
	void holidays()
	{
		System.out.println("This is a holiday");
	}
	
}
class Hello extends Mindsprint
{
	void leave()
	{
		System.out.println("Today is a leave");
	}
	void comp2()
	{
		System.out.println("This is comp2");
	}
}
public class Abstraction {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Hello mnc;
		mnc = new Hello();
		mnc.leave();
		mnc.holidays();
		mnc.comp2();
		mnc.comp1();

	}

}
