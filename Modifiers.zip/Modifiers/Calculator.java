package Modifiers;

public class Calculator {
	public void add(int a,int b)
	{
		int res=a+b;
		System.out.println("The sum is :"+res);
	}
	public void add(float a,float b)
	{
		float res=a+b;
		System.out.println("The sum is :"+res);
	}
	public void add(long a,long b)
	{
		long res=a+b;
		System.out.println("The sum is :"+res);
	}
	public void add(double a,double b)
	{
		double res=a+b;
		System.out.println("The sum is :"+res);
	}
	public void subtract(int a,int b)
	{
		int res=a-b;
		System.out.println("The difference is :"+res);
	}
	public void subtract(float a,float b)
	{
		float res=a-b;
		System.out.println("The difference is :"+res);
	}
	public void subtract(long a,long b)
	{
		long res=a-b;
		System.out.println("The difference is :"+res);
	}
	public void subtract(double a,double b)
	{
		double res=a-b;
		System.out.println("The difference is :"+res);
	}
	public void multiply(int a,int b)
	{
		int res=a*b;
		System.out.println("The multi is :"+res);
	}
	public void multiply(float a,float b)
	{
		float res=a*b;
		System.out.println("The multi is :"+res);
	}
	public void multiply(long a,long b)
	{
		long res=a*b;
		System.out.println("The multi is :"+res);
	}
	public void multiply(double a,double b)
	{
		double res=a*b;
		System.out.println("The multi is :"+res);
	}
	public void divide(int a,int b)
	{
		if(b==0)
		{
			System.out.println("Division not possible");
		}
		int res=a/b;
		System.out.println("The division is: "+res);
	}
	public void divide(float a,float b)
	{
		if(b==0)
		{
			System.out.println("Division not possible");
		}
		float res=a/b;
		System.out.println("The division is: "+res);
	}
	public void divide(long a,long b)
	{
		if(b==0)
		{
			System.out.println("Division not possible");
		}
		long res=a/b;
		System.out.println("The division is: "+res);
	}
	public void divide(double a,double b)
	{
		if(b==0)
		{
			System.out.println("Division not possible");
		}
		double res=a/b;
		System.out.println("The division is: "+res);
	}
	public void even(int a)
	{
		if((a%2)!=0)
			System.out.println("This is odd");
		System.out.println("This is even :"+a);
	}
	public void isprime(int a)
	{
		if(a<2)
			System.out.println("Not prime");
		for(int i=2;i<=Math.sqrt(a);i++)
		{
			if((a%i)==0)
			{
				System.out.println("Not prime");
				break;
			}
				
			
		}
		System.out.println("Prime "+a);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calculator c = new Calculator();
		c.add(5, 4);
		c.add(7.6f, 8.5f);
		c.add(4324342, 42234);
		c.subtract(65, 8);
		c.subtract(5.67f, 4.56f);
		c.subtract(463738393, 4763839);
		c.multiply(56, 5);
		c.multiply(6.7, 3.5);
		c.multiply(4930,8339);
		c.divide(9, 3);
		c.divide(6.33f, 2f);
		c.divide(4637389, 36378);
		c.even(64);
		c.isprime(23);
	}

}
