package Modifiers;

public class SI {
	public float calcSI(int principle,float interest, int time)
	{
		float result=(principle*interest*time)/100;
		return result;
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int p=1000;
		float r=10.3f;
		int t=6;
		SI p1 = new SI();
		float res=p1.calcSI(p, r, t);
		float f=p+res;
		System.out.println("Interest is :"+res+" Final Amount: "+f);

	}

}
